# Author: Kenji Kashima
# Date  : 2023/11/05
# Note  : You should install scipy first.
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize

np.random.seed(13)
plt.rc('text', usetex=True) # use latex


def func_z(z, invbeta, l, P):
    """f(z) % find the solution of equation (11.23)"""
    return (z[0]**invbeta-l[0]*P[:,0]@z)**2 +\
           (z[1]**invbeta-l[1]*P[:,1]@z)**2 +\
           (z[2]**invbeta-l[2]*P[:,2]@z)**2 +\
           (z[3]**invbeta-l[3]*P[:,3]@z)**2 
         
def func_v(v, beta, a, b, P):
    """f(v)  % find the solution of equation below (11.29)"""
    return  beta*a@v + b@\
            np.array([[np.log(P[:,0]@np.exp(-beta*v))],
                      [np.log(P[:,1]@np.exp(-beta*v))],
                      [np.log(P[:,2]@np.exp(-beta*v))],
                      [np.log(P[:,3]@np.exp(-beta*v))]])

def figure11_4(N_k= 1000, sigma = 1.0):
    # Figure 11.2 (a) transition probability
    P = np.array([[1/3,    1/3,      0,      0],
                  [0  ,    1/3,    1/3,      0],
                  [0  ,    1/3,    1/3,    1/3],
                  [2/3,      0,    1/3,    2/3]])
    # accumulated transition probability
    m,n =P.shape
    beta = 0.8
    invbeta = 1/beta
    sigma = sigma
    cost = np.array([0, 1, 2, 3]) * sigma
    l = np.exp(-beta*cost)  # l=exp(-cost)
    results = minimize(fun=func_z,x0= np.ones(4)*5, args=(invbeta,l,P),method = "l-bfgs-b",
                       options={'gtol': 1e-6})
    z_opt = results.x
    P_opt = np.zeros((m,n))
    for i in range(m):
        for j in range(n):
            P_opt[i,j]=P[i,j]*z_opt[i]/(P[:,j]@z_opt)
    
    print("sigma:",sigma, "Ppi:\n", P_opt)
    # Note:        
    # You can obtain the following result by the Matlab code
    # Similar results can be obtained by this program by adjusting sigma. 
    # However, with different solver the reults will be a little different.
    # % Figure 11.3(a) sigma=1.0
    # % Ppi =
    # %    0.8795    0.4556         0         0
    # %         0    0.4066    0.7063         0
    # %         0    0.1378    0.2394    0.6883
    # %    0.1205         0    0.0542    0.3117
    # %
    # % Figure 11.3(b) sigma=1.2
    # % Ppi =
    # %    0.9388    0.5108         0         0
    # %         0    0.3856    0.7623         0
    # %         0    0.1036    0.2048    0.7567
    # %    0.0612         0    0.0329    0.2433

    P_accum = np.zeros((m,n))
    P_accum[0,:] = P_opt[0,:]
    for i in range(1,m):
        P_accum[i,:]= P_accum[i-1,:]+P_opt[i,:]


    p_list = np.zeros(N_k+1,dtype=np.int8) 
    p_list[0] = 4 
    # start at 4
    a, b=np.array([0,0,0,1]), np.array([0,0,0,1])
    inv_l = np.zeros(n)
    inv_l_hist =np.zeros((4,N_k))
    cons = ({'type': 'eq', 'fun': lambda x:  x[0]-1},
            {'type': 'ineq', 'fun': lambda x: x[0]},
            {'type': 'ineq', 'fun': lambda x: x[1]},
            {'type': 'ineq', 'fun': lambda x: x[2]},
            {'type': 'ineq', 'fun': lambda x: x[3]})
    for i in range(N_k):
        results = minimize(fun=func_v,x0= np.array([1,0,0,0]), args=(beta,a,b,P),
                        constraints= cons ,options={'gtol': 1e-6})
        inv_v_opt =results.x
        inv_z_opt = np.exp(-beta*inv_v_opt)
        inv_z_opt_beta = inv_z_opt ** invbeta
        
        for j in range(n):
            inv_l[j]=inv_z_opt_beta[j]/(P[:,j]@inv_z_opt)

        inv_l=inv_l/inv_l[0]
        inv_l_hist[:,i] = -np.log(inv_l)/beta

        u = np.random.rand()
        T = P_accum[:,int(p_list[i])-1] #transition probability
        for j in range(m):
            if u <= T[j]:
                p_list[i+1] = j+1
                break
        #record how many times of the state has been visited
        a[p_list[i+1]-1] +=1 
        b[p_list[i]-1] +=1

    plt.figure('Figure11.4(a)')
    plt.stairs(p_list)
    plt.ylim([0.8,4.2])
    plt.xlim([0,200])
    plt.xlabel(r"$k$",fontsize=16)
    plt.title(r"$P^0$",fontsize=16)
    plt.grid()
    plt.show()

    plt.figure('Figure11.4(b)')
    for i in range(4):
        plt.plot(inv_l_hist[i,:],label=r"$\ell_{}$".format(i+1))
    plt.ylim([-0.5,5.5])
    plt.xlim([0,1000])
    plt.xlabel(r"$k$",fontsize=16)
    plt.title(r"$P^0$",fontsize=16)
    plt.legend(fontsize=16)
    plt.grid()
    plt.show()

if __name__ == '__main__':
    figure11_4(N_k=1000,sigma=1.0)
