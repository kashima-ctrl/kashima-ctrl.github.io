% Author: Kenji Kashima
% Date  : 2023/10/01
% Note  : Optimization Toolbox is required

clear;close all; rng(3); % random seed

% Kullbuck-Leibler control
n = 4; N_k =1000;
% Figure 11.2 (a) transition probability
% P^0 in equation (11.21)
P = [1/3    1/3      0      0;
       0    1/3    1/3      0;
       0    1/3    1/3    1/3;
     2/3      0    1/3    2/3];

beta = 0.8;
invbeta = 1/beta;
sigma = 1.0;
cost = [0 1 2 3]*sigma;
l = exp(-beta*cost);  % l=exp(-cost);

funz = @(z)(z(1)^invbeta-l(1)*P(:,1)'*z)^2 +... 
           (z(2)^invbeta-l(2)*P(:,2)'*z)^2 +...
           (z(3)^invbeta-l(3)*P(:,3)'*z)^2 +...
           (z(4)^invbeta-l(4)*P(:,4)'*z)^2;
z0 = ones(4,1)*5; % inital z
z_opt = fmincon(funz,z0); % find the solution of equation (11.23)

%find the P_star in equation (11.21)
P_opt = zeros(n,n);
for i=1:n
    for j=1:n
        P_opt(i,j)=P(i,j)*z_opt(i)/(P(:,j)'*z_opt);
    end
end

% accumulated transition probability
[m,n] =size(P_opt);
P_accum = zeros(m,n);
P_accum(1,:) = P_opt(1,:);
for i = 2:m
    P_accum(i,:)= P_accum(i-1,:)+P_opt(i,:);
end
% Figure 11.3(a) sigma=1.0
% Ppi =
%    0.8795    0.4556         0         0
%         0    0.4066    0.7063         0
%         0    0.1378    0.2394    0.6883
%    0.1205         0    0.0542    0.3117
%
% Figure 11.3(b) sigma=1.2
% Ppi =
%    0.9388    0.5108         0         0
%         0    0.3856    0.7623         0
%         0    0.1036    0.2048    0.7567
%    0.0612         0    0.0329    0.2433


x=[4 zeros(1,N_k-1)];
a=[0,0,0,1]; b=[0,0,0,1];
inv_l = zeros(n,1); 
inv_l_hist =zeros(4,N_k);
for i=1:N_k
    % find the solution of equation below (11.29)
    funv = @(v)( beta*a*v + b* ...
                [log(P(:,1)'*exp(-beta*v));
                 log(P(:,2)'*exp(-beta*v));
                 log(P(:,3)'*exp(-beta*v));
                 log(P(:,4)'*exp(-beta*v))]);
    v0 = [1;0;0;0];
    inv_v_opt = fmincon(funv,v0,-eye(n), zeros(4,1),[1 0 0 0],1); 
    % constrants:
    % v(1)=1
    % -I * v <= [0;0;0;0]  (v(i)>=0, i = 1,2,3,4)
    
    inv_z_opt = exp(-beta*inv_v_opt);
    inv_z_opt_beta = inv_z_opt.^invbeta;
    
    for j=1:n
        inv_l(j)=inv_z_opt_beta(j)/(P(:,j)'*inv_z_opt);
    end
    inv_l=inv_l/inv_l(1);
    inv_l_hist(:,i) = -log(inv_l)/beta;
    u = rand;
    T = P_accum(:,x(i)); %transition probability
    for j = 1:m
        if u <= T(j)
             x(i+1) = j;
             break
        end
    end
    % record how many times of the state has been visited
    a(x(i+1))=a(x(i+1))+1; 
    b(x(i))=b(x(i))+1;
end


figure('Name','Figure11.4(a)'); hold on; grid on;
stairs(x);
xlim([0,200]);
ylim([0.8,4.2]);
xlabel('$k$','Fontsize',16,'Interpreter','latex')
title('$P^\pi\ (\sigma=1)$','Fontsize',16,'Interpreter','latex')
grid on;


figure('Name','Figure11.4(b)'); hold on; grid on;   
plot(inv_l_hist(:,:)');
ylim([-0.5,5.5]);
xlim([0,1000]);
legend('$\ell_1$', '$\ell_2$','$\ell_3$','$\ell_4$','Fontsize',16,'Interpreter','latex')
xlabel('$k$','Fontsize',16,'Interpreter','latex')
grid on;



