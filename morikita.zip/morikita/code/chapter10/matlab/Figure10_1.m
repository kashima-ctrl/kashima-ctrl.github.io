% Author: Kenji Kashima
% Date  : 2023/09/30
% Note  : % エントロピー正則化最適制御　経路積分 離散値L0制御
clear;close all; rng(5); % random seed

dt = 0.003;
N_k = 100;  % the number of steps k_bar (bar here means the final one)
N_s = 1000; % the number of samples
epi_num = 3; % the number of the sampled pathes

eps = 0.15; % regularization weight　epsilon

A = eye(2) + 0.05*[0 1;0 0];
B = [0.00125;0.05];

u_max = 5;  % 入力上限
u_min = -5; % 入力下限

u_num = 5; % 入力空間の要素数
u_list = [u_min,u_min/2,0,u_max/2,u_max]; % 入力空間
p_w = zeros(u_num,1);
noise_policy = zeros(u_num,1);
optimal_policy = zeros(u_num,1);

% generate the CDF_list for the noise drived policy
% equation (10.22,10.23) c_k(u) = sign(u)^2, c_k_bar = sum(c_k) (c_k is p_w here)
for i = 1:u_num
    p_w(i) = exp(-1/eps*cost_u(u_list(i)));
end
c_bar = sum(p_w);
p_w = p_w/c_bar;
noise_policy(1) = p_w(1);
for i = 2:u_num
    noise_policy(i) = noise_policy(i-1) + p_w(i);
end

%% generate the trajectories
x = [4; 4];

Q = zeros(u_num,1);     
u = zeros(N_k,epi_num);
x1 = zeros(N_k+1,epi_num);
x2 = zeros(N_k+1,epi_num);

x1(1,:) = x(1);
x2(1,:) = x(2);

u_prob = zeros(u_num,1);
for epi = 1:epi_num
    tic
    for k = 1:N_k
        x1_tmp = x1(k,epi);
        x2_tmp = x2(k,epi);
        x_tmp = [x1_tmp;x2_tmp];

        for j = 1:u_num
            x_next = A*x_tmp + B*u_list(j);
            costs = zeros(1,N_s);
            % generate trajectories based on the noise driven policy
            for s = 1:N_s
                x_bar = x_next;
                for i = k+1:N_k   
                    w = stochastic_policy(u_list,noise_policy);
                    costs(1,s) = costs(1,s) +dt* cost_x(x_bar,false); % equation (10.25)
                    x_bar = A*x_bar + B*w;
                end
                costs(1,s) = costs(1,s) + dt*cost_x(x_bar,true); %Terminal cost
            end

            % Z-function
            Z_tmp = 0;
            for s = 1:N_s
                l_s = costs(:,s);
                Z_tmp = Z_tmp + exp(-1/eps*l_s);
            end
            Z_star =c_bar^(N_k-k) * Z_tmp/N_s;      % equation (10.25)
            V_star = -eps * log(Z_star);            % equation (10.26)

            Q(j) = cost_u(u_list(j)) + V_star;  % Q-function
        end

        % find the CDF list of the optimal policy
        for i = 1:u_num
            u_prob(i) = exp(-1/eps*Q(i));
        end
        u_prob = u_prob/sum(u_prob);
        optimal_policy(1) = u_prob(1);
        for i = 2:u_num
            optimal_policy(i) = optimal_policy(i-1) + u_prob(i);
        end
        
        u_opt = stochastic_policy(u_list,optimal_policy);
        x_next = A*x_tmp + B*u_opt;
        % logging
        u(k,epi) = u_opt;
        x1(k+1,epi) = x_next(1);
        x2(k+1,epi) = x_next(2);     
    end
    toc   
end

figure
hold on
for epi = 1:epi_num
    plot(x1(:,epi),x2(:,epi),'Linewidth',3)
end
grid on
set(gca,'Fontsize',16)
xlabel('$x_1$','Interpreter','latex','Fontsize', 24)
ylabel('$x_2$','Interpreter','latex','Fontsize', 24)

movegui('south')
figure
u_time = linspace(0,N_k-1,N_k);
tiledlayout(epi_num,1)

nexttile
stairs(u_time,u(:,1),'Linewidth',3,'Color','#0072BD')
ylim([u_min,u_max])
grid on
set(gca,'Fontsize',16)

nexttile
stairs(u_time,u(:,2),'Linewidth',3,'Color','#D95319')
ylim([u_min,u_max])
grid on
set(gca,'Fontsize',16)
ylabel('$u_k$','Interpreter','latex','Fontsize', 24)

nexttile
stairs(u_time,u(:,3),'Linewidth',3,'Color','#EDB120')
ylim([u_min,u_max])
grid on
set(gca,'Fontsize',16)
xlabel('$k$','Interpreter','latex','Fontsize', 24)

function l_bar =  cost_x(x_bar,isTerminal)
    if isTerminal
        l_bar = 4* norm(x_bar)^2;
    else
        l_bar = norm(x_bar)^2;
    end
end

function c = cost_u(u)
    % the cost function for input part
    if u==0
        c = 0;
    else
        c = 1;
    end
end

function u = stochastic_policy(action_list, CDF_list)
    % action_list: action space ; 
    % CDF_list: Cumulative Distribution Function list
    %           e.g. CDF_list = [0.2,0.4,0.5,0.8,1.0]
    
    tmp = rand;
    for i = 1:length(action_list)  
        if tmp < CDF_list(i) 
            u = action_list(i);
            break
        end
    end
end

