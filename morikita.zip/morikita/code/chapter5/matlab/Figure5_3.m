% Author: Kenji Kashima
% Date  : 2023/03/12
% Note  : You need to install CVX toolkit first: http://cvxr.com/cvx/

clear;close all; rng(1); % random seed

n_k = 100; % total steps

% parameters for a discrete-time system
A = [1.12 -0.49; 1 0];
C = [1 0];


% size_x = 2; size_y = 1; % observation for x_1 only in this example
[size_y,size_x] = size(C);

%See Example 5.3.3
q = 0.1;  % coefficient of w_k
r = 0.1;  % coefficient of v_k

sigma0 = 0.4*eye(2); % prior covirance matrix
mu0 = [3;2];         % prior mean value

y = zeros(1,n_k);
x_true = zeros(size_x,n_k);

x = mvnrnd(mu0, sigma0)'; % x0~N(mu_0, 0.4*I)
x_true(:,1)=x;
for k = 1:n_k-1
    w = randl(size_x,1); % sample w from laplace distribution
    v = randl(size_y);   % sample v from laplace distribution
    y(k) = C*x + r*v;
    x = A*x + q*w; % x_{k+1}
    x_true(:,k+1)=x;   
end
v = randl(size_y);   % sample v from laplace distribution
y(k+1) = C*x + r*v;

 
% Obtain the auxiliary matrix for solving the optimal problem
Aux1 = get_Aux1(A,C,n_k);
Aux2 = get_Aux2(A,C,n_k);


% See eqation (5.54)
cvx_begin
    variables u(size_x*n_k) x0(size_x)  % define variables u_{1:k}.flatten()  x0
    minimize quad_form(x0-mu0,inv(sigma0))... % 2.5||x0-mu0||^2
        + 1/q*norm(u,1)  ...                  % 10 \sum_{k=0}^{n_k-1}||u_k||_1
        + 1/r*norm(y'-(Aux1*x0+ Aux2*u),1)    % 10 \sum_{k=0}^{n_k-1}||Cx_k-y_k||_1
cvx_end                                       % O*x0=Cx_{1:n_k}


% Recall the auxiliary matrix for ploting
aux1 = get_Aux1(A,eye(2),n_k);
aux2 = get_Aux2(A,eye(2),n_k);
X = aux1*x0 + aux2*u;   % estimated state
X = reshape(X,size_x,n_k); 

figure('Name','Figure 5.3(a)'); hold on; grid on;
plot(0:n_k-1,x_true(1,:),'LineWidth',2)
plot(0:n_k-1,X(1,:),'LineWidth',2)
plot(0:n_k-1,y,'LineWidth',2)
legend('$x^{(1)}$ true','$x^{(1)}$ esitmate','$y$ obaservation','Interpreter','latex','Fontsize',16)
xlabel('$k$','Interpreter','latex','Fontsize',16)
xlim([0,n_k-1])
movegui('northwest')

figure('Name','Figure 5.3(b)'); hold on; grid on;
plot(0:n_k-1,x_true(2,:),'LineWidth',2)
plot(0:n_k-1,X(2,:),'LineWidth',2)
legend('$x^{(2)}$ true','$x^{(2)}$ esitmate','Interpreter','latex','Fontsize',16)
xlabel('$k$','Interpreter','latex','Fontsize',16)
xlim([0,n_k-1])



% This two functions obtain auxiliary matrix for calculating
% \sum_{k=0}^{n_k-1}||Cx_k-y_k||_1,
% where x_k = A^k * x0 + A^(k-1)*u_0 + A^(k-2)*u_1 ...
function Aux1= get_Aux1(A,C,n_k)
[size_y,size_x] = size(C);
Aux1 = zeros(n_k*size_y, size_x);
for k = 1:n_k
   Aux1((k-1)*size_y+1:k*size_y,:) = C*A^(k-1);
end
% Aux1 is for the x0 related part.
% e.g. n_k=3 Aux1 = [C,CA,CA^2]'           
end

function Aux2= get_Aux2(A,C,n_k)
[size_y,size_x] = size(C); 
Aux2 = zeros(n_k*size_y, n_k*size_x);
for k = 1:n_k-1
    Aux2(k*size_y+1:n_k*size_y,(k-1)*size_x+1:k*size_x) = get_Aux1(A,C,n_k-k);
end
% Aux2 is for the u related part.
% e.g.         [ O   , O,  O, O ]         
%              [ C   , O,  O, O ]
% n_k=4 Aux2 = [ CA  , C,  O, O ]
%              [ CA^2, CA, C, O ]
end
