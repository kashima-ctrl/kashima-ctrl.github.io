# Author: Kenji Kashima
# Date  : 2023/03/12
# Note  : pip install cvxpy
#  (important!!!) You need to install cvxpy first!!!

import numpy as np
import matplotlib.pyplot as plt
from cvxpy import Minimize,Variable,Problem
from cvxpy.atoms import quad_form,norm

np.random.seed(1)
plt.rc('text', usetex=True) # use latex

'''
% This two functions obtain auxiliary matrix for calculating
% \sum_{k=0}^{n_k-1}||Cx_k-y_k||_1,
% where x_k = A^k * x0 + A^(k-1)*u_0 + A^(k-2)*u_1 ...
'''
def get_Aux1(A:np.ndarray,C:np.ndarray,n_k:int)->np.ndarray:
    [size_y,size_x] = np.shape(C)  
    Aux1 = np.zeros([n_k*size_y, size_x])
    for k in range(n_k):
        Aux1[k*size_y:(k+1)*size_y,:] = C @ np.linalg.matrix_power(A,k)
    return Aux1
    # Aux1 is for the x0 related part.
    # e.g. n_k=3 Aux1 = [C,CA,CA^2]'           


def get_Aux2(A:np.ndarray,C:np.ndarray,n_k:int)->np.ndarray:
    [size_y,size_x] = np.shape(C)  
    Aux2 = np.zeros([n_k*size_y, n_k*size_x])
    for k in range(n_k-1):
        Aux2[(k+1)*size_y:n_k*size_y,k*size_x:(k+1)*size_x] = get_Aux1(A,C,n_k-(k+1))
    return Aux2
    #  Aux2 is for the u related part.
    #  e.g.         [ O   , O,  O, O ]         
    #               [ C   , O,  O, O ]
    #  n_k=4 Aux2 = [ CA  , C,  O, O ]
    #               [ CA^2, CA, C, O ]



def figure5_3(n_k:int=100):
    '''
        n_k - total steps
    '''

    # parameters for a discrete-time system
    A = np.array([[1.12,-0.49], [1,0]])
    C = np.array([[1,0]])
    [size_y,size_x] = np.shape(C)

    # See Example 5.3.3
    q = 0.1  # coefficient of w_k
    r = 0.1  # coefficient of v_k

    sigma0 = 0.4 * np.eye(2)  # prior covirance matrix
    mu0 = np.array([3,2]) # prior mean value

    y = np.zeros(n_k)
    x_true = np.zeros([n_k,size_x])

    x = np.random.multivariate_normal(mu0, sigma0).reshape(size_x,1) # x0~N(mu_0, 0.4*I)
    x_true[0]=x.flatten()
    for k in range(n_k-1):
        w = np.random.laplace(loc=0,scale=1,size=(size_x,1)) # sample w from laplace distribution
        v = np.random.laplace(loc=0,scale=1,size=size_y)     # sample v from laplace distribution
        y[k] = C @ x + r * v
        x = A @ x + q * w   # x_{k+1}
        x_true[k+1]=x.flatten()
    
    v = np.random.laplace(loc=0,scale=1,size=size_y)     # sample v from laplace distribution
    y[n_k-1] = C @ x + r * v

 
    # Obtain the auxiliary matrix for solving the optimal problem
    Aux1 = get_Aux1(A,C,n_k)
    Aux2 = get_Aux2(A,C,n_k)
    pass

    # See eqation (5.54)
    u = Variable(size_x*n_k) # define variable u_{0:k-1}.flatten()  
    x0 = Variable(size_x)    # define variable x0
    obj = Minimize(2.5*quad_form(x0-mu0,np.eye(size_x))+    # 2.5||x0-mu0||^2
                   1/q*norm(u,1)+                           # 10 \sum_{k=0}^{n_k-1}||u_k||_1
                   1/r*norm(y.T-(Aux1 @ x0 + Aux2 @ u),1))  # 10 \sum_{k=0}^{n_k-1}||Cx_k-y_k||_1
    prob = Problem(obj)
    prob.solve()

    # Recall the auxiliary matrix for ploting
    AUX1 = get_Aux1(A,np.eye(2),n_k)
    AUX2 = get_Aux2(A,np.eye(2),n_k)
    X0 = x0.value.reshape([2,1])
    U = u.value.reshape([n_k*size_x,1])
    X = AUX1 @ X0 + AUX2 @ U   # estimated state
    X = X.reshape([n_k,size_x])
    
    k_list = np.arange(0,n_k)

    '''Figure 5.3(a)'''
    plt.figure()
    plt.plot(k_list,x_true[:,0],linewidth=2.0,alpha=0.8,label=r'$x^{(1)}$ true')
    plt.plot(k_list,X[:,0],linewidth=2.0,alpha=0.8,label=r'$x^{(1)}$ esitmate')
    plt.plot(k_list,y,linewidth=2.0,alpha=0.8,label=r'$y$ obaservation')
    plt.xlim([0,n_k-1])
    plt.xlabel(r'$k$',fontsize=18)
    plt.tight_layout()
    plt.legend(fontsize=16)
    plt.grid()

    '''Figure 5.3(b)'''
    plt.figure() 
    plt.plot(k_list,x_true[:,1],linewidth=2.0,alpha=0.8,label=r'$x^{(2)}$ true')
    plt.plot(k_list,X[:,1],linewidth=2.0,alpha=0.8,label=r'$x^{(2)}$ esitmate')
    plt.xlim([0,n_k-1])
    plt.xlabel(r'$k$',fontsize=18)
    plt.tight_layout()
    plt.legend(fontsize=16)
    plt.grid()

    plt.show()
    
if __name__ == '__main__':
    figure5_3(n_k=100)
