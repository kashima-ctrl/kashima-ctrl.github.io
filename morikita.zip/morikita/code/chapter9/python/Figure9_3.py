# Author: Kenji Kashima
# Date  : 2023/09/30
import numpy as np
import matplotlib.pyplot as plt
import control

np.random.seed(23)

N_iter = 50
beta = 0.95          # discount rate (LQR for 1)

n_x, n_u = 100, 5
A = np.random.rand(n_x,n_x)
A = A/np.max(np.abs(np.linalg.eig(A)[0]))
B = np.random.rand(n_x,n_u)

QRS = np.random.rand(n_x+n_u,n_x+n_u)    # initialized randomly
QRS = QRS@QRS.T                 # to make QRS positive definite
Q = QRS[0:n_x,0:n_x]            # stage cost x'Qx + u'Ru + 2*u'Sx
R = QRS[n_x:n_x+n_u,n_x:n_x+n_u]    
S = QRS[n_x:n_x+n_u,0:n_x]

# Optimal gain 
_,PI_opt,_ = control.dlqr(A*np.sqrt(beta),B*np.sqrt(beta),Q,R,S.T)

# Value iteration 
err_list_VI = np.zeros(N_iter)
PI = np.zeros((n_x,n_x))

for i in range(N_iter):
    Rt = R + beta * B.T@PI@B
    St = S + beta * B.T@PI@A
    Qt = Q + beta * A.T@PI@A 
    PIt = Qt - St.T @ np.linalg.inv(Rt) @ St   #Rt\St means inv(Rt) * St
    Kt = np.linalg.inv(Rt) @ St

    err_list_VI[i]= np.linalg.norm(PI_opt-PIt)
    PI = PIt

# Policy iteration 
err_list_PI =np.zeros(N_iter)
Kt = np.zeros((n_u,n_x))

for i in range(N_iter):
    tmp = np.block([np.eye(n_x), -Kt.T])@ np.block([[Q, S.T],[S,R]])@ np.block([[np.eye(n_x)],[-Kt]])
    tmp = (tmp + tmp.T)/2 # make sure tmp is symmetric
    PI_Q = control.dlyap(np.sqrt(beta)*(A-B@Kt).T, tmp) 
    Rt = R + beta * B.T@PI_Q@B
    St = S + beta * B.T@PI_Q@A
    Qt = Q + beta * A.T@PI_Q@A
    PIt = Qt - St.T @ np.linalg.inv(Rt) @ St # for Riccati error calculation
    Kt = np.linalg.inv(Rt) @ St
    
    err_list_PI[i] =  np.linalg.norm(PI_opt-PIt)

plt.figure('Figure 9.3')
plt.semilogy(err_list_VI,'b',label= "Value Iteration")
plt.semilogy(err_list_PI,'r',label ="Policy Iteration")
plt.legend(fontsize=16)
plt.ylim([1e-10,1000])
plt.xlim([0,10])
plt.grid()
plt.show()

