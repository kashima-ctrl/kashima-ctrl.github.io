# Author: Kenji Kashima
# Date  : 2023/02/24

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(100)
plt.rc('text', usetex=True) # use latex

def figure3_3a(n_k:int=50,n_sample:int=9):
    '''
        n_k - total steps

        n_sample - number of samples
    '''
    for i in range(n_sample):
        x = np.zeros(n_k)
        x[0] = -0.8+0.2*i # initialization
        for k in range(n_k-1):
             x[k+1] =  x[k] + 0.1*(x[k]-x[k]**3)
        plt.plot(x,linewidth=2)
    plt.xlim([1,n_k-1])
    plt.xlabel(r'$k$',fontsize=18)
    plt.ylabel(r'$x_k$',fontsize=18)
    plt.tight_layout()
    plt.show()

def figure3_3b(n_k:int=50,n_sample:int=10):
    '''
        n_k - total steps

        n_sample - number of samples
    '''
    for _ in range(n_sample):
        x = np.zeros(n_k)
        x[0] = -0.5 # initialization
        # Note: rand is a single uniformly distributed random 
        # number in the interval (0,1).
        for k in range(n_k-1):
             rand = np.random.rand()
             x[k+1] =  x[k] + 0.1*(x[k]-x[k]**3) + 0.5*(rand*2-1.0)*(1-np.abs(x[k])) 
        plt.plot(x,linewidth=2)
    plt.xlim([1,n_k-1])
    plt.ylim([-1,1])
    plt.xlabel(r'$k$',fontsize=18)
    plt.ylabel(r'$x_k$',fontsize=18)
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    figure3_3a(n_k=50,n_sample=9)
    figure3_3b(n_k=50,n_sample=10)
