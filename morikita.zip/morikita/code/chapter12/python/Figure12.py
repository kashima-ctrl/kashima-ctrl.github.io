# Author: Kenji Kashima
# Date  : 2023/11/05
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(23)
plt.rc('text', usetex=True) # use latex

def figure12_2(N_k= 100):
    C = [0.5, 0.5, 1.0, 1.0]
    alpha = [1.0, 0.3, 1.0, 1.5]

    x_list = np.zeros((4,N_k+1))
    y_list = np.zeros((4,N_k))
    plt.figure('Figure12.2(a)')  # Please change N_k = 10000 to obtain Figure12.2(b)
    x_list[:,0] = np.ones_like(x_list[:,0])*10 #start at 10.0
    for k in range(4):
        for i in range(N_k):        
            x = x_list[k,i]
            y_list[k,i] = x - np.random.randn()   # mean estimation
            x_list[k,i+1] = x - C[k]/((i+1)**alpha[k]) * y_list[k,i]
        plt.plot(x_list[k,:],label=r"$C={}, \alpha={}$".format(C[k],alpha[k]))

    plt.scatter(0.0,10.0,marker='*',label= "Initial Value") # start point
    plt.ylabel(r"$x_k$",fontsize=16)
    plt.xlabel(r"$k$",fontsize=16)
    plt.xlim([0,N_k])
    plt.legend(fontsize=16)
    plt.grid()
    plt.show()

def figure12_3a():
    plt.figure('Figure12.3(a)')
    x = np.arange(-5,5,0.01)
    y = x**2/2-x*np.cos(x*10)/20+np.sin(x*10)/20
    plt.plot(x,y,label=r'${\mathcal L}(x)$')
    y = x+x*np.sin(x*10)/2
    plt.plot(x,y,label=r"$f(x)$")
    y = x
    plt.plot(x,y,label=r'$f_1(x)$')
    y = x*np.sin(x*10)/2
    plt.plot(x,y,label=r"$f_2(x)$")
    
    plt.legend(fontsize=16)
    plt.grid()
    plt.ylabel(r"$x_k$",fontsize=16)
    plt.xlabel(r"$k$",fontsize=16)
    plt.show()

def figure12_3b(N_k= 1000):
    C = [1.0, 1.0]
    alpha = [0.4,0.7]

    x_list = np.zeros((2,N_k+1))
    y_list = np.zeros((2,N_k))
    plt.figure('Figure12.3(b)')  
    x_list[:,0] = np.ones_like(x_list[:,0])*2 #start at 2.0
    for k in range(2):
        for i in range(N_k):        
            x = x_list[k,i]
            randn = np.random.randn()
            if randn< 0.5:
                y_list[k,i] = 2*x + randn*10;   # solving x^2 =2
            else:
                y_list[k,i] = x*np.sin(x*10) + randn*10;   # solving x^2 =2

            x_list[k,i+1] = x - C[k]/((i+1)**alpha[k]) * y_list[k,i]
        plt.plot(x_list[k,:],label=r"$\alpha={}$".format(alpha[k]))

    plt.scatter(0.0,2.0,marker='*',label= "Initial Value",color="red") # start point
    plt.ylabel(r"$x_k$",fontsize=16)
    plt.xlabel(r"$k$",fontsize=16)
    plt.xlim([0,N_k])
    plt.ylim([-10,10])
    plt.legend(fontsize=16)
    plt.grid()
    plt.show()



if __name__ == '__main__':
    #figure12_2(N_k=100)   #Figure12.2(a)
    #figure12_2(N_k=10000) #Figure12.2(b)
    #figure12_3a()
    figure12_3b()









