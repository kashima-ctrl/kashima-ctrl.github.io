% Author: Kenji Kashima
% Date  : 2023/11/05

figure('Name','Figure12.3(a)'); hold on; grid on;
x = -5:0.01:5;
y = x.^2/2-x.*cos(x*10)/20+sin(x*10)/20;
plot(x,y);
y = x+x.*sin(x*10)/2;
plot(x,y);
y = x;
plot(x,y)
y = x.*sin(x*10)/2;
plot(x,y)
grid on;
xlabel('$x$','Interpreter','latex','Fontsize',18);
ylabel('$x_k$','Interpreter','latex','Fontsize',18);
legend('${\mathcal L}(x)$','$f(x)$','$f_1(x)$','$f_2(x)$','Interpreter','latex','Fontsize',10)