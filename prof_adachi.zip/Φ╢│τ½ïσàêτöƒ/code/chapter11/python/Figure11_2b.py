# Author: Kenji Kashima
# Date  : 2023/11/05
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(23)
plt.rc('text', usetex=True) # use latex

def figure11_2b(N_k= 300):
    # Figure 11.2 (a) transition probability
    P = np.array([[1/3,    1/3,      0,      0],
                  [0  ,    1/3,    1/3,      0],
                  [0  ,    1/3,    1/3,    1/3],
                  [2/3,      0,    1/3,    2/3]])
    
    # accumulated transition probability
    m,n =P.shape
    P_accum = np.zeros((m,n))
    P_accum[0,:] = P[0,:]
    for i in range(1,m):
        P_accum[i,:]= P_accum[i-1,:]+P[i,:]


    p_list = np.zeros(N_k) 
    p_list[0] = 4 # start at 4

    for i in range(1,N_k):
        u = np.random.rand()
        T = P_accum[:,int(p_list[i-1])-1] #transition probability
        for j in range(m):
            if u <= T[j]:
                p_list[i] = j+1
                break

    plt.figure('Figure11.2(b)')
    plt.stairs(p_list)
    plt.ylim([0.8,4.2])
    plt.xlim([0,200])
    plt.xlabel(r"$k$",fontsize=16)
    plt.title(r"$P^0$",fontsize=16)
    plt.grid()
    plt.show()

if __name__ == '__main__':
    figure11_2b(N_k=300)










