# Author: Kenji Kashima
# Date  : 2023/02/25
# Note  : pip install control

import control as ctl
import numpy as np
import matplotlib.pyplot as plt

np.random.seed(1)
plt.rc('text', usetex=True) # use latex

def figure3_4a():
    # Chebyshev Type II filter design
    den = [1.0000,-2.2741,1.7904,-0.4801]
    num = [0.0159, 0.0022,0.0022, 0.0159]
    dsys= ctl.tf(num,den,dt=True)

    mag, _, omega = ctl.frequency_response(dsys,np.arange(0,np.pi,0.01))
    plt.plot(omega,mag,linewidth=1.0,color='blue',label='frequency weight')
    plt.plot([0,0.25,0.6,np.pi],[1,1,0,0],linewidth=2,linestyle='--',color='red',label='prior information')
    plt.xlabel(r'$\varpi$',fontsize=18)
    plt.grid()
    plt.legend(fontsize=16)
    plt.tight_layout()
    plt.show()

def figure3_4b(n_k:int=200):
    '''n_k - total steps'''
    # Chebyshev Type II filter design
    den = [1.0000,-2.2741,1.7904,-0.4801]
    num = [0.0159, 0.0022,0.0022, 0.0159]
    dsys= ctl.tf(num,den,dt=1.0) # discrete-time interval is 1.0s
    dsys = ctl.tf2io(dsys)       # Convert a transfer function into an I/O system 
    u_k = np.random.randn(n_k+1) # random input
    data = ctl.input_output_response(dsys,T=np.arange(0,201),U=u_k)
    y_k = data.y[0,:]
    plt.xlabel(r'$k$',fontsize=18)
    plt.xlim(0,200)
    plt.ylim(-2,2)
    plt.stairs(u_k,label='white')
    plt.stairs(y_k,linewidth=1.0,label='colored')
    plt.legend(fontsize=16,loc='upper right')
    plt.grid()
    plt.show()


if __name__ == '__main__':
    figure3_4a()
    figure3_4b(n_k=200)