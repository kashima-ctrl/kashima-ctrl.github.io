# Author: Kenji Kashima
# Date  : 2023/02/24

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(100)
plt.rc('text', usetex=True) # use latex

def figure3_1a(n_k:int=50,n_sample:int=10):
    '''
        n_k - total steps

        n_sample - number of samples
    '''
    for _ in range(n_sample):
        x = np.zeros(n_k)
        rand = np.random.rand()
        x[0] = rand-0.5 # initialization
        # Note: rand is a single uniformly distributed random 
        # number in the interval (0,1).
        for k in range(n_k-1):
             rand = np.random.rand()
             x[k+1] =  x[k] + 0.1*(x[k]-x[k]**3) + 0.5*(rand-0.5)*(1-np.abs(x[k])) 
        plt.plot(x,linewidth=2)
    plt.xlim([1,n_k-1])
    plt.xlabel(r'$k$',fontsize=18)
    plt.ylabel(r'$x_k$',fontsize=18)
    plt.tight_layout()
    plt.show()

def figure3_1b(n_k=9):
    '''
        n_k - number of k
    '''
    n_tmp = 1000
    n_x = 2*n_tmp+1 # number of x
    x = np.linspace(-1,1,n_x)
    P = np.zeros([n_x,n_x])
    for i in range(n_x):
        tmp_u = x[i] + 0.1*(x[i]-x[i]**3) + 0.5*(1-np.abs(x[i]))
        tmp_l = x[i] + 0.1*(x[i]-x[i]**3) - 0.5*(1-np.abs(x[i]))
        index_u = int(np.ceil((tmp_u+1)*n_tmp))+1
        index_l = int(np.floor((tmp_l+1)*n_tmp))+1    
        for j in range(index_l,index_u):
            P[j,i]=P[j,i]+1/(index_u-index_l+1)

    states = np.zeros([n_x,n_k+2]); 
    states[n_tmp+1,0]=1;  #initialization
    for i in range(n_k+1):
        states[:,i+1] = P @ states[:,i]
    fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
    for i in range(1,n_k+1):
        k=np.ones(n_x)*(i-1)
        phi=states[:,i]*n_x/2
        ax.plot3D(k,x.T,phi)
    ax.set_xlabel(r'$k$',fontsize=18)
    ax.set_ylabel(r'$x$',fontsize=18)
    ax.zaxis.set_rotate_label(False)
    ax.set_zlabel(r'$\varphi_{x_k}$',fontsize=18,rotation=90)
    ax.view_init(8, -120)
    ax.set_yticks([-1,-0.5,0,0.5,1])
    plt.grid()
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    figure3_1a(n_k=50,n_sample=10)
    figure3_1b(n_k=9)
